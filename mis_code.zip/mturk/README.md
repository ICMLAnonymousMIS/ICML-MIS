# UI of the Psychophyiscal Experiments
This folder contains the frontend of the psychophysical experiments optimized for an online experiment in a web browser.

This code was originally released by Zimmermann et al. 2023. We use it without any modification.
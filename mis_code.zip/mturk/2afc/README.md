# UI of the 2AFC Psychophyiscal Experiment
This folder contains the frontend of the psychophysical experiment used to replicate the results of Borowski et al. 2021.

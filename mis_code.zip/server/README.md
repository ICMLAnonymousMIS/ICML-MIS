Things regarding the web server required for the experiment.
Run the whole pipeline by calling [run.sh](run.sh). If this is the first run of `run.sh`, initialize the setup by executing the [init script for the SSL encryption](web-data/init-letsencrypt.sh).

The folder [web-data/nginx](web-data/nginx) contains the configuration file for the HTTP web server, i.e. nginx.
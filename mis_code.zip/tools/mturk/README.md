Code to [start](spawn_experiment.py) an experiment on AWS MTurk, i.e. repeatedly post new HITs on MTurk until we collected enough responses for each task.

This code was originally released by Zimmermann et al. 2023. We use it without any modification.

## Data Analysis
This folder contains scripts to analyse the data from the experiments. 
The jupyter notebooks to analyse each experiment (pre-study, pilot, actual experiment) are stored in their respective folders.

(TODO This will be added in a new PR)
